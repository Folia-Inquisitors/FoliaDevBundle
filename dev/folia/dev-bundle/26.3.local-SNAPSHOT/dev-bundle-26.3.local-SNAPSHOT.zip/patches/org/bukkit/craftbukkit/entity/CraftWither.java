package org.bukkit.craftbukkit.entity;

import com.google.common.base.Preconditions;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import org.bukkit.boss.BossBar;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.boss.CraftBossBar;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Wither;

public class CraftWither extends CraftMonster implements Wither, com.destroystokyo.paper.entity.CraftRangedEntity<WitherBoss> { // Paper

    private final BossBar bossBar;

    public CraftWither(CraftServer server, WitherBoss entity) {
        super(server, entity);
        this.bossBar = new CraftBossBar(entity.bossEvent);
    }

    @Override
    public WitherBoss getHandle() {
        ca.spottedleaf.moonrise.common.util.TickThread.ensureTickThread(this.entity, "Accessing entity state off owning region's thread"); // Folia - region threading
        return (WitherBoss) this.entity;
    }

    @Override
    public BossBar getBossBar() {
        return this.bossBar;
    }

    @Override
    public void setTarget(Head head, LivingEntity livingEntity) {
        Preconditions.checkArgument(head != null, "head cannot be null");

        int entityId = (livingEntity != null) ? livingEntity.getEntityId() : 0;
        this.getHandle().setAlternativeTarget(head.ordinal(), entityId);
    }

    @Override
    public LivingEntity getTarget(Head head) {
        Preconditions.checkArgument(head != null, "head cannot be null");

        int entityId = this.getHandle().getAlternativeTarget(head.ordinal());
        if (entityId == 0) {
            return null;
        }
        net.minecraft.world.entity.LivingEntity target = (net.minecraft.world.entity.LivingEntity) this.getHandle().level().getEntity(entityId);
        return (target != null) ? target.getBukkitEntity() : null;
    }

    @Override
    public int getInvulnerabilityTicks() {
        return this.getHandle().getInvulnerableTicks();
    }

    @Override
    public void setInvulnerabilityTicks(int ticks) {
        Preconditions.checkArgument(ticks >= 0, "ticks must be >=0");

        this.getHandle().setInvulnerableTicks(ticks);
    }

    @Override
    public boolean isCharged() {
        return getHandle().isPowered();
    }

    @Override
    public int getInvulnerableTicks() {
        return getHandle().getInvulnerableTicks();
    }

    @Override
    public void setInvulnerableTicks(int ticks) {
        getHandle().setInvulnerableTicks(ticks);
    }

    @Override
    public boolean canTravelThroughPortals() {
        return getHandle().canUsePortal(false);
    }

    @Override
    public void setCanTravelThroughPortals(boolean value) {
        getHandle().setCanTravelThroughPortals(value);
    }

    @Override
    public void enterInvulnerabilityPhase() {
        this.getHandle().makeInvulnerable();
    }
}
