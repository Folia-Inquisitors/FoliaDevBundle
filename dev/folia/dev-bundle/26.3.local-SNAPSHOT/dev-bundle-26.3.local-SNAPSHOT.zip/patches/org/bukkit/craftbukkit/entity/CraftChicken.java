package org.bukkit.craftbukkit.entity;

import com.google.common.base.Preconditions;
import io.papermc.paper.registry.HolderableBase;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.animal.chicken.ChickenSoundVariant;
import net.minecraft.world.entity.animal.chicken.ChickenVariant;
import org.bukkit.craftbukkit.CraftRegistry;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.entity.Chicken;
import org.jspecify.annotations.NullMarked;

@NullMarked
public class CraftChicken extends CraftAnimals implements Chicken {

    public CraftChicken(CraftServer server, net.minecraft.world.entity.animal.chicken.Chicken entity) {
        super(server, entity);
    }

    @Override
    public net.minecraft.world.entity.animal.chicken.Chicken getHandle() {
        ca.spottedleaf.moonrise.common.util.TickThread.ensureTickThread(this.entity, "Accessing entity state off owning region's thread"); // Folia - region threading
        return (net.minecraft.world.entity.animal.chicken.Chicken) this.entity;
    }

    @Override
    public Variant getVariant() {
        return CraftVariant.minecraftHolderToBukkit(this.getHandle().getVariant());
    }

    @Override
    public void setVariant(Variant variant) {
        Preconditions.checkArgument(variant != null, "variant cannot be null");

        this.getHandle().setVariant(CraftVariant.bukkitToMinecraftHolder(variant));
    }

    @Override
    public SoundVariant getSoundVariant() {
        return CraftSoundVariant.minecraftHolderToBukkit(this.getHandle().getSoundVariant());
    }

    @Override
    public void setSoundVariant(final SoundVariant variant) {
        Preconditions.checkArgument(variant != null, "variant cannot be null");

        this.getHandle().setSoundVariant(CraftSoundVariant.bukkitToMinecraftHolder(variant));
    }

    public static class CraftVariant extends HolderableBase<ChickenVariant> implements Variant {

        public static Variant minecraftHolderToBukkit(Holder<ChickenVariant> minecraft) {
            return CraftRegistry.minecraftHolderToBukkit(minecraft, Registries.CHICKEN_VARIANT);
        }

        public static Holder<ChickenVariant> bukkitToMinecraftHolder(Variant bukkit) {
            return CraftRegistry.bukkitToMinecraftHolder(bukkit);
        }

        public CraftVariant(Holder<ChickenVariant> holder) {
            super(holder);
        }
    }

    public static class CraftSoundVariant extends HolderableBase<ChickenSoundVariant> implements SoundVariant {

        public static SoundVariant minecraftHolderToBukkit(Holder<ChickenSoundVariant> minecraft) {
            return CraftRegistry.minecraftHolderToBukkit(minecraft, Registries.CHICKEN_SOUND_VARIANT);
        }

        public static Holder<ChickenSoundVariant> bukkitToMinecraftHolder(SoundVariant bukkit) {
            return CraftRegistry.bukkitToMinecraftHolder(bukkit);
        }

        public CraftSoundVariant(final Holder<ChickenSoundVariant> holder) {
            super(holder);
        }
    }

    @Override
    public boolean isChickenJockey() {
        return this.getHandle().isChickenJockey();
    }

    @Override
    public void setIsChickenJockey(boolean isChickenJockey) {
        this.getHandle().setChickenJockey(isChickenJockey);
    }

    @Override
    public int getEggLayTime() {
        return this.getHandle().eggTime;
    }

    @Override
    public void setEggLayTime(int eggLayTime) {
        this.getHandle().eggTime = eggLayTime;
    }
}
