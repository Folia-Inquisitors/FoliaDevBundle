package org.bukkit.craftbukkit.entity;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.util.CraftLocation;
import org.bukkit.entity.Turtle;

public class CraftTurtle extends CraftAnimals implements Turtle {

    public CraftTurtle(CraftServer server, net.minecraft.world.entity.animal.turtle.Turtle entity) {
        super(server, entity);
    }

    @Override
    public net.minecraft.world.entity.animal.turtle.Turtle getHandle() {
        ca.spottedleaf.moonrise.common.util.TickThread.ensureTickThread(this.entity, "Accessing entity state off owning region's thread"); // Folia - region threading
        return (net.minecraft.world.entity.animal.turtle.Turtle) this.entity;
    }

    @Override
    public boolean hasEgg() {
        return this.getHandle().hasEgg();
    }

    @Override
    public boolean isLayingEgg() {
        return this.getHandle().isLayingEgg();
    }

    @Override
    public org.bukkit.Location getHome() {
        return CraftLocation.toBukkit(this.getHandle().getHomePos(), this.getHandle().level());
    }

    @Override
    public void setHome(org.bukkit.Location location) {
        this.getHandle().setHomePos(CraftLocation.toBlockPos(location));
    }

    @Override
    public boolean isGoingHome() {
        return this.getHandle().goingHome;
    }

    @Override
    public void setHasEgg(boolean hasEgg) {
        this.getHandle().setHasEgg(hasEgg);
    }
}
