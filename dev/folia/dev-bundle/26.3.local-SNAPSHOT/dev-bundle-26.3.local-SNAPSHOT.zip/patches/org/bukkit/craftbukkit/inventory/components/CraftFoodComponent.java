package org.bukkit.craftbukkit.inventory.components;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.world.food.FoodProperties;
import org.bukkit.configuration.serialization.SerializableAs;
import org.bukkit.craftbukkit.inventory.SerializableMeta;
import org.bukkit.inventory.meta.components.FoodComponent;
import org.checkerframework.checker.index.qual.NonNegative;

import static io.papermc.paper.util.BoundChecker.requireNonNegative;

@SerializableAs("Food")
public final class CraftFoodComponent implements FoodComponent {

    private FoodProperties handle;

    public CraftFoodComponent(FoodProperties food) {
        this.handle = food;
    }

    public CraftFoodComponent(CraftFoodComponent food) {
        this.handle = food.handle;
    }

    public CraftFoodComponent(Map<String, Object> map) {
        Integer nutrition = SerializableMeta.getObject(Integer.class, map, "nutrition", false);
        Float saturationModifier = SerializableMeta.getObject(Float.class, map, "saturation", false);
        Boolean canAlwaysEat = SerializableMeta.getBoolean(map, "can-always-eat");

        this.handle = new FoodProperties(nutrition, saturationModifier, canAlwaysEat);
    }

    @Override
    public Map<String, Object> serialize() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("nutrition", this.getNutrition());
        result.put("saturation", this.getSaturation());
        result.put("can-always-eat", this.canAlwaysEat());

        return result;
    }

    public FoodProperties getHandle() {
        return this.handle;
    }

    @Override
    public int getNutrition() {
        return this.handle.nutrition();
    }

    @Override
    public void setNutrition(@NonNegative int nutrition) {
        this.handle = new FoodProperties(requireNonNegative(nutrition, "nutrition"), this.handle.saturation(), this.handle.canAlwaysEat());
    }

    @Override
    public float getSaturation() {
        return this.handle.saturation();
    }

    @Override
    public void setSaturation(float saturation) {
        this.handle = new FoodProperties(this.handle.nutrition(), saturation, this.handle.canAlwaysEat());
    }

    @Override
    public boolean canAlwaysEat() {
        return this.handle.canAlwaysEat();
    }

    @Override
    public void setCanAlwaysEat(boolean canAlwaysEat) {
        this.handle = new FoodProperties(this.handle.nutrition(), this.handle.saturation(), canAlwaysEat);
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 73 * hash + this.handle.hashCode();
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || this.getClass() != obj.getClass()) {
            return false;
        }
        final CraftFoodComponent other = (CraftFoodComponent) obj;
        return this.handle.equals(other.handle);
    }

    @Override
    public String toString() {
        return "CraftFoodComponent{component=" + this.handle + '}';
    }
}
