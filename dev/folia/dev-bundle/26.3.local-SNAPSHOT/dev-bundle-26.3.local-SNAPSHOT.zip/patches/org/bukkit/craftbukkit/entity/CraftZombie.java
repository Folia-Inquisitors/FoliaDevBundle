package org.bukkit.craftbukkit.entity;

import com.google.common.base.Preconditions;
import net.minecraft.world.entity.monster.zombie.ZombieVillager;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.entity.Villager;
import org.bukkit.entity.Zombie;

public class CraftZombie extends CraftMonster implements Zombie {

    public CraftZombie(CraftServer server, net.minecraft.world.entity.monster.zombie.Zombie entity) {
        super(server, entity);
    }

    @Override
    public net.minecraft.world.entity.monster.zombie.Zombie getHandle() {
        ca.spottedleaf.moonrise.common.util.TickThread.ensureTickThread(this.entity, "Accessing entity state off owning region's thread"); // Folia - region threading
        return (net.minecraft.world.entity.monster.zombie.Zombie) this.entity;
    }

    @Override
    public boolean isBaby() {
        return this.getHandle().isBaby();
    }

    @Override
    public void setBaby(boolean baby) {
        CraftAgeable.setBaby(this.getHandle(), baby);
    }

    @Override
    public boolean isVillager() {
        return this.getHandle() instanceof ZombieVillager;
    }

    @Override
    public void setVillager(boolean flag) {
        throw new UnsupportedOperationException("Not supported.");
    }

    @Override
    public void setVillagerProfession(Villager.Profession profession) {
        throw new UnsupportedOperationException("Not supported.");
    }

    @Override
    public Villager.Profession getVillagerProfession() {
        return null;
    }

    @Override
    public boolean isConverting() {
        return this.getHandle().isUnderWaterConverting();
    }

    @Override
    public int getConversionTime() {
        Preconditions.checkState(this.isConverting(), "Entity not converting");

        return this.getHandle().drowningTracker.conversionTime;
    }

    @Override
    public void setConversionTime(int time) {
        if (time < 0) {
            this.getHandle().drowningTracker.setConverting(false);
            this.getHandle().drowningTracker.setAfflictionTime(-1);
        } else {
            this.startDrowning(time);
        }
    }

    @Override
    public int getAge() {
        return this.getHandle().isBaby() ? -1 : 0;
    }

    @Override
    public void setAge(int age) {
        this.getHandle().setBaby(age < 0);
    }

    @Override
    public void setAgeLock(boolean lock) {
    }

    @Override
    public boolean isDrowning() {
        return this.getHandle().isUnderWaterConverting();
    }

    @Override
    public void startDrowning(int time) {
        this.getHandle().drowningTracker.startConversion(time);
    }

    @Override
    public void stopDrowning() {
        this.setConversionTime(-1);
    }

    @Override
    public boolean shouldBurnInDay() {
        return this.getHandle().isSunSensitive();
    }

    @Override
    public boolean isArmsRaised() {
        return this.getHandle().isAggressive();
    }

    @Override
    public void setArmsRaised(final boolean raised) {
        this.getHandle().setAggressive(raised);
    }

    @Override
    public void setShouldBurnInDay(boolean shouldBurnInDay) {
        this.getHandle().setShouldBurnInDay(shouldBurnInDay);
    }

    @Override
    public boolean getAgeLock() {
        return false;
    }

    @Override
    public void setBaby() {
        CraftAgeable.setBaby(this.getHandle(), true);
    }

    @Override
    public void setAdult() {
        CraftAgeable.setBaby(this.getHandle(), false);
    }

    @Override
    public boolean isAdult() {
        return !this.getHandle().isBaby();
    }

    @Override
    public boolean canBreed() {
        return false;
    }

    @Override
    public void setBreed(boolean breed) {
    }

    @Override
    public boolean canBreakDoors() {
        return this.getHandle().canBreakDoors();
    }

    @Override
    public void setCanBreakDoors(boolean flag) {
        this.getHandle().setCanBreakDoors(flag);
    }
}
