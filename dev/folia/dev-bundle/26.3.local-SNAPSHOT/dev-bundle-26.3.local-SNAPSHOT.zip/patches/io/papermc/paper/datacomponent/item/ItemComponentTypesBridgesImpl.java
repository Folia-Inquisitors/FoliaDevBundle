package io.papermc.paper.datacomponent.item;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.google.common.base.Preconditions;
import io.papermc.paper.registry.data.util.Conversions;
import io.papermc.paper.registry.set.PaperRegistrySets;
import io.papermc.paper.registry.set.RegistryKeySet;
import io.papermc.paper.text.Filtered;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.util.TriState;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.component.OminousBottleAmplifier;
import org.bukkit.JukeboxSong;
import org.bukkit.block.BlockType;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.damage.DamageType;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ItemType;
import org.bukkit.inventory.meta.trim.ArmorTrim;
import org.bukkit.map.MapCursor;
import org.jspecify.annotations.Nullable;

import static io.papermc.paper.util.BoundChecker.requireNonNegative;
import static io.papermc.paper.util.BoundChecker.requirePositive;
import static io.papermc.paper.util.BoundChecker.requireRange;

public final class ItemComponentTypesBridgesImpl implements ItemComponentTypesBridge {

    @Override
    public ChargedProjectiles.Builder chargedProjectiles() {
        return new PaperChargedProjectiles.BuilderImpl();
    }

    @Override
    public PotDecorations.Builder potDecorations() {
        return new PaperPotDecorations.BuilderImpl();
    }

    @Override
    public ItemLore.Builder lore() {
        return new PaperItemLore.BuilderImpl();
    }

    @Override
    public ItemEnchantments.Builder enchantments() {
        return new PaperItemEnchantments.BuilderImpl();
    }

    @Override
    public ItemAttributeModifiers.Builder modifiers() {
        return new PaperItemAttributeModifiers.BuilderImpl();
    }

    @Override
    public FoodProperties.Builder food() {
        return new PaperFoodProperties.BuilderImpl();
    }

    @Override
    public DyedItemColor.Builder dyedItemColor() {
        return new PaperDyedItemColor.BuilderImpl();
    }

    @Override
    public PotionContents.Builder potionContents() {
        return new PaperPotionContents.BuilderImpl();
    }

    @Override
    public BundleContents.Builder bundleContents() {
        return new PaperBundleContents.BuilderImpl();
    }

    @Override
    public SuspiciousStewEffects.Builder suspiciousStewEffects() {
        return new PaperSuspiciousStewEffects.BuilderImpl();
    }

    @Override
    public MapDecorations.Builder mapDecorations() {
        return new PaperMapDecorations.BuilderImpl();
    }

    @Override
    public MapDecorations.DecorationEntry mapDecorationEntry(final MapCursor.Type type, final double x, final double z, final float rotation) {
        return PaperMapDecorations.PaperDecorationEntry.toApi(type, x, z, rotation);
    }

    @Override
    public SeededContainerLoot.Builder seededContainerLoot(final Key lootTableKey) {
        return new PaperSeededContainerLoot.BuilderImpl(lootTableKey);
    }

    @Override
    public ItemContainerContents.Builder itemContainerContents() {
        return new PaperItemContainerContents.BuilderImpl();
    }

    @Override
    public JukeboxPlayable.Builder jukeboxPlayable(final JukeboxSong song) {
        return new PaperJukeboxPlayable.BuilderImpl(song);
    }

    @Override
    public Tool.Builder tool() {
        return new PaperItemTool.BuilderImpl();
    }

    @Override
    public Tool.Rule toolRule(final RegistryKeySet<BlockType> blocks, final @Nullable Float speed, final TriState correctForDrops) {
        return PaperItemTool.PaperRule.fromUnsafe(blocks, speed, correctForDrops);
    }

    @Override
    public ItemAdventurePredicate.Builder itemAdventurePredicate() {
        return new PaperItemAdventurePredicate.BuilderImpl();
    }

    @Override
    public WrittenBookContent.Builder writtenBookContent(final Filtered<String> title, final String author) {
        return new PaperWrittenBookContent.BuilderImpl(title, author);
    }

    @Override
    public WritableBookContent.Builder writeableBookContent() {
        return new PaperWritableBookContent.BuilderImpl();
    }

    @Override
    public ItemArmorTrim.Builder itemArmorTrim(final ArmorTrim armorTrim) {
        return new PaperItemArmorTrim.BuilderImpl(armorTrim);
    }

    @Override
    public LodestoneTracker.Builder lodestoneTracker() {
        return new PaperLodestoneTracker.BuilderImpl();
    }

    @Override
    public Fireworks.Builder fireworks() {
        return new PaperFireworks.BuilderImpl();
    }

    @Override
    public ResolvableProfile resolvableProfile(final PlayerProfile profile) {
        return PaperResolvableProfile.toApi(profile);
    }

    @Override
    public ResolvableProfile.Builder resolvableProfile() {
        return new PaperResolvableProfile.BuilderImpl();
    }

    @Override
    public ResolvableProfile.SkinPatchBuilder skinPatch() {
        return new PaperResolvableProfile.SkinPatchBuilderImpl();
    }

    @Override
    public ResolvableProfile.SkinPatch emptySkinPatch() {
        return new PaperResolvableProfile.PaperSkinPatch(null, null, null, null);
    }

    @Override
    public BannerPatternLayers.Builder bannerPatternLayers() {
        return new PaperBannerPatternLayers.BuilderImpl();
    }

    @Override
    public BlockItemDataProperties.Builder blockItemStateProperties() {
        return new PaperBlockItemDataProperties.BuilderImpl();
    }

    @Override
    public MapId mapId(final int id) {
        return new PaperMapId(new net.minecraft.world.level.saveddata.maps.MapId(id));
    }

    @Override
    public UseRemainder useRemainder(final ItemStack item) {
        Preconditions.checkArgument(item != null, "item cannot be null");
        Preconditions.checkArgument(!item.isEmpty(), "item cannot be empty!");
        return new PaperUseRemainder(
            new net.minecraft.world.item.component.UseRemainder(CraftItemStack.asTemplate(item))
        );
    }

    @Override
    public Consumable.Builder consumable() {
        return new PaperConsumable.BuilderImpl();
    }

    @Override
    public UseCooldown.Builder useCooldown(final float seconds) {
        return new PaperUseCooldown.BuilderImpl(requirePositive(seconds, "seconds"));
    }

    @Override
    public DamageResistant damageResistant(final RegistryKeySet<DamageType> types) {
        return new PaperDamageResistant(new net.minecraft.world.item.component.DamageResistant(PaperRegistrySets.convertToNms(Registries.DAMAGE_TYPE, Conversions.global().lookup(), types)));
    }

    @Override
    public Enchantable enchantable(final int level) {
        return new PaperEnchantable(new net.minecraft.world.item.enchantment.Enchantable(level));
    }

    @Override
    public Repairable repairable(final RegistryKeySet<ItemType> types) {
        return new PaperRepairable(new net.minecraft.world.item.enchantment.Repairable(
            PaperRegistrySets.convertToNms(Registries.ITEM, Conversions.global().lookup(), types)
        ));
    }

    @Override
    public Equippable.Builder equippable(EquipmentSlot slot) {
        return new PaperEquippable.BuilderImpl(slot);
    }

    @Override
    public DeathProtection.Builder deathProtection() {
        return new PaperDeathProtection.BuilderImpl();
    }

    @Override
    public CustomModelData.Builder customModelData() {
        return new PaperCustomModelData.BuilderImpl();
    }

    @Override
    public PaperOminousBottleAmplifier ominousBottleAmplifier(final int amplifier) {
        return new PaperOminousBottleAmplifier(
            new OminousBottleAmplifier(requireRange(amplifier, "amplifier", OminousBottleAmplifier.MIN_AMPLIFIER, OminousBottleAmplifier.MAX_AMPLIFIER))
        );
    }

    @Override
    public BlocksAttacks.Builder blocksAttacks() {
        return new PaperBlocksAttacks.BuilderImpl();
    }

    @Override
    public TooltipDisplay.Builder tooltipDisplay() {
        return new PaperTooltipDisplay.BuilderImpl();
    }

    @Override
    public Weapon.Builder weapon() {
        return new PaperWeapon.BuilderImpl();
    }

    @Override
    public KineticWeapon.Builder kineticWeapon() {
        return new PaperKineticWeapon.BuilderImpl();
    }

    @Override
    public KineticWeapon.Condition kineticWeaponCondition(int maxDurationTicks, float minSpeed, float minRelativeSpeed) {
        return new PaperKineticWeapon.PaperKineticWeaponCondition(new net.minecraft.world.item.component.KineticWeapon.Condition(
            maxDurationTicks, minSpeed, requireNonNegative(minRelativeSpeed, "minRelativeSpeed")
        ));
    }

    @Override
    public UseEffects.Builder useEffects() {
        return new PaperUseEffects.BuilderImpl();
    }

    @Override
    public PiercingWeapon.Builder piercingWeapon() {
        return new PaperPiercingWeapon.BuilderImpl();
    }

    @Override
    public AttackRange.Builder attackRange() {
        return new PaperAttackRange.BuilderImpl();
    }

    @Override
    public SwingAnimation.Builder swingAnimation() {
        return new PaperSwingAnimation.BuilderImpl();
    }

    @Override
    public SulfurCubeContent sulfurCubeContent(final ItemStack absorbedItem) {
        Preconditions.checkArgument(absorbedItem != null, "absorbedItem cannot be null");
        Preconditions.checkArgument(!absorbedItem.isEmpty(), "absorbedItem cannot be empty");
        return new PaperSulfurCubeContent(new net.minecraft.world.item.component.SulfurCubeContent(CraftItemStack.asTemplate(absorbedItem)));
    }

    @Override
    public MobVisibility mobVisibility(final RegistryKeySet<EntityType> targetingEntityTypes, final float visibility) {
        return new PaperMobVisibility(new net.minecraft.world.item.component.MobVisibility(
            PaperRegistrySets.convertToNms(Registries.ENTITY_TYPE, Conversions.global().lookup(), targetingEntityTypes),
            requireRange(visibility, "visibility", net.minecraft.world.item.component.MobVisibility.MIN_VISIBILITY, net.minecraft.world.item.component.MobVisibility.MAX_VISIBILITY))
        );
    }

    @Override
    public VillagerFood villagerFood(final int nutrition) {
        return new PaperVillagerFood(new net.minecraft.world.food.VillagerFood(requirePositive(nutrition, "nutrition")));
    }

    @Override
    public SignText.Builder signText() {
        return new PaperSignText.BuilderImpl();
    }
}
