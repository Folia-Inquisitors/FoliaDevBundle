package io.papermc.paper.world;

import ca.spottedleaf.concurrentutil.lock.Notifier;
import ca.spottedleaf.concurrentutil.map.concurrent.ints.ConcurrentChainedInt2ReferenceHashTable;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.util.Optional;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.maps.MapId;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;
import net.minecraft.world.level.storage.SavedDataStorage;
import org.bukkit.event.server.MapInitializeEvent;
import org.jspecify.annotations.Nullable;

/**
 * Unloads map data that is no longer used.
 *
 * <p>A map is in one of three states:</p>
 * <ul>
 *     <li><b>Loaded</b>: in the storage cache, so it is saved.</li>
 *     <li><b>Unloaded</b>: only referenced weakly here. It stays in memory as long as something else references it,
 *     e.g. a plugin holding its MapView. Using it again loads that same object, without reading it from disk or
 *     calling MapInitializeEvent again.</li>
 *     <li><b>Collected</b>: nothing referenced it anymore. Using it again reads it from disk.</li>
 * </ul>
 *
 * <p>Maps are unloaded by {@link #unloadUnused}, which runs before map data is saved. A map is unloaded when it was
 * not used since the previous run and nothing holds it: no player carries or views it, and no plugin changed its
 * renderers (those live on the MapView and would be lost).</p>
 *
 * <p>Since unloaded maps are not saved, the file of an unloaded map must stay up to date until it is collected:</p>
 * <ul>
 *     <li>A map is only unloaded when its file is up to date: it is not dirty and no write is pending. This is only
 *     reliable on the thread that saves map data (the dirty flag is cleared when a save is scheduled, not when it
 *     completes), so {@link #unloadUnused} must run on that thread.</li>
 *     <li>An unloaded map is loaded again before it changes: the game only changes maps it just got through
 *     {@link #get}, or that a player holds, and MapView changes go through {@link #markDirty}.
 *     Data returned by {@link #get} must not be kept and changed across a call to {@link #unloadUnused} (in
 *     practice, across ticks) unless a player holds the map.</li>
 * </ul>
 *
 * <p>All other methods can be called from any thread. A map is only returned to other threads once
 * MapInitializeEvent was called for it, so that they see the renderers plugins add in it.</p>
 */
public final class MapDataCache {

    private final MinecraftServer server;
    /** Maps that do not exist are loaded too, with null data. */
    private final ConcurrentChainedInt2ReferenceHashTable<LoadedMap> loaded = new ConcurrentChainedInt2ReferenceHashTable<>();
    private final ConcurrentChainedInt2ReferenceHashTable<UnloadedMap> unloaded = new ConcurrentChainedInt2ReferenceHashTable<>();
    private final ReferenceQueue<MapItemSavedData> collectedMaps = new ReferenceQueue<>();

    public MapDataCache(final MinecraftServer server) {
        this.server = server;
    }

    public @Nullable MapItemSavedData get(final MapId id) {
        while (true) {
            final LoadedMap map = this.getOrLoad(id);
            map.awaitInitialized();
            if (map.markUsed()) {
                return map.data;
            }
            // The map is being unloaded right now, wait for that to finish and load it again
            Thread.onSpinWait();
        }
    }

    /** Sets the data of a new map and calls MapInitializeEvent for it. */
    public void set(final MapId id, final MapItemSavedData data) {
        data.id = id;
        final LoadedMap map = new LoadedMap(data);
        map.initialization = new Initialization(Thread.currentThread(), new Notifier(true));
        this.loaded.compute(id.id(), (key, previous) -> {
            this.unloaded.remove(key);
            this.storage().set(MapItemSavedData.type(id), data);
            return map;
        });

        // Called outside of the table lock, getting the map from a listener finds the new map
        try {
            new MapInitializeEvent(data.mapView).callEvent();
        } finally {
            map.finishInitializing();
        }
    }

    /** Marks the map dirty, and loads it again if it is unloaded so that the change is saved. */
    public void markDirty(final MapItemSavedData data) {
        data.setDirty();
        this.markUsed(data);
    }

    /** Marks the map used, and loads it again if it is unloaded. */
    public void markUsed(final MapItemSavedData data) {
        if (data.id != null) {
            this.get(data.id);
        }
    }

    private LoadedMap getOrLoad(final MapId id) {
        final LoadedMap existing = this.loaded.get(id.id());
        if (existing != null) {
            return existing;
        }

        final boolean[] readFromDisk = {false};
        final LoadedMap map = this.loaded.computeIfAbsent(id.id(), key -> {
            final MapItemSavedData stillReferenced = this.takeUnloaded(key);
            if (stillReferenced != null) {
                this.storage().cache.put(MapItemSavedData.type(id), Optional.of(stillReferenced));
                return new LoadedMap(stillReferenced);
            }
            readFromDisk[0] = true;
            final LoadedMap read = new LoadedMap(this.storage().get(MapItemSavedData.type(id)));
            if (read.data != null) {
                read.initialization = new Initialization(Thread.currentThread(), new Notifier(true));
            }
            return read;
        });

        // Called outside of the table lock, getting the map from a listener finds the loaded map
        if (readFromDisk[0] && map.data != null) {
            try {
                map.data.id = id;
                new MapInitializeEvent(map.data.mapView).callEvent();
            } finally {
                map.finishInitializing();
            }
        }
        return map;
    }

    private @Nullable MapItemSavedData takeUnloaded(final int id) {
        final UnloadedMap unloadedMap = this.unloaded.remove(id);
        return unloadedMap == null ? null : unloadedMap.get();
    }

    /** Unloads maps that were not used since the previous call. Must be called on the thread that saves map data, before saving. */
    public void unloadUnused() {
        this.forgetCollectedMaps();

        // Files on disk may be outdated until the pending writes complete
        if (this.storage().hasPendingWrites()) {
            return;
        }

        for (final ConcurrentChainedInt2ReferenceHashTable.TableEntry<LoadedMap> entry : this.loaded) {
            final LoadedMap map = entry.getValue();
            if (map.checkAndResetUsed()) {
                continue;
            }
            if (map.data != null && !canUnload(map.data)) {
                continue;
            }
            if (map.tryMarkUnloading()) {
                this.unload(entry.getKey(), map);
            }
        }
    }

    private static boolean canUnload(final MapItemSavedData data) {
        synchronized (data) {
            return !data.isDirty() && data.carriedBy.isEmpty() && data.mapView.hasOnlyDefaultRenderer();
        }
    }

    private void unload(final int id, final LoadedMap map) {
        // Make the map available to load again before it is no longer loaded
        if (map.data != null) {
            this.unloaded.put(id, new UnloadedMap(id, map.data, this.collectedMaps));
        }
        this.storage().cache.remove(MapItemSavedData.type(new MapId(id)), Optional.ofNullable(map.data));
        this.loaded.remove(id, map);
    }

    private void forgetCollectedMaps() {
        Reference<? extends MapItemSavedData> collected;
        while ((collected = this.collectedMaps.poll()) != null) {
            final UnloadedMap unloadedMap = (UnloadedMap) collected;
            this.unloaded.remove(unloadedMap.id, unloadedMap);
        }
    }

    private SavedDataStorage storage() {
        return this.server.getDataStorage();
    }

    /**
     * Using a map and unloading it can happen at the same time on different threads. Each side writes its own flag,
     * then reads the other's (both volatile), so at least one of them sees the other: either unloading sees that the
     * map was used and does not unload it, or using it sees that it is being unloaded and loads it again.
     */
    private static final class LoadedMap {
        private final @Nullable MapItemSavedData data;
        private volatile boolean used = true;
        private volatile boolean unloading;
        /** Set while MapInitializeEvent is called for the map. */
        private volatile @Nullable Initialization initialization;

        private LoadedMap(final @Nullable MapItemSavedData data) {
            this.data = data;
        }

        /** Waits until MapInitializeEvent was called, unless the map is being initialized by this thread (e.g. a listener gets it). */
        private void awaitInitialized() {
            final Initialization initialization = this.initialization;
            if (initialization != null && initialization.thread() != Thread.currentThread()) {
                initialization.done().waitUntilReady();
            }
        }

        private void finishInitializing() {
            final Initialization initialization = this.initialization;
            this.initialization = null;
            initialization.done().notifyThreads();
        }

        /** Returns false if the map is being unloaded. */
        private boolean markUsed() {
            this.used = true;
            return !this.unloading;
        }

        private boolean checkAndResetUsed() {
            if (this.used) {
                this.used = false;
                return true;
            }
            return false;
        }

        /** Returns false if the map was used concurrently. */
        private boolean tryMarkUnloading() {
            this.unloading = true;
            if (this.used) {
                this.unloading = false;
                return false;
            }
            return true;
        }
    }

    private record Initialization(Thread thread, Notifier done) {
    }

    private static final class UnloadedMap extends WeakReference<MapItemSavedData> {
        private final int id;

        private UnloadedMap(final int id, final MapItemSavedData data, final ReferenceQueue<MapItemSavedData> queue) {
            super(data, queue);
            this.id = id;
        }
    }
}
