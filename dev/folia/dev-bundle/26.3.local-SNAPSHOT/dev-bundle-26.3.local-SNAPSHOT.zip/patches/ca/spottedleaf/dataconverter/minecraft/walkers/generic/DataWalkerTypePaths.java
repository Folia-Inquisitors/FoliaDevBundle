package ca.spottedleaf.dataconverter.minecraft.walkers.generic;

import ca.spottedleaf.converter.datatypes.DataType;
import ca.spottedleaf.converter.datatypes.DataWalker;
import ca.spottedleaf.converter.types.MapType;

public class DataWalkerTypePaths<T, R> extends DataWalker<MapType> {

    protected final DataType<T, R> type;
    protected final String[] paths;

    public DataWalkerTypePaths(final DataType<T, R> type, final String... paths) {
        this.type = type;
        this.paths = paths;
    }

    @Override
    public final MapType walk(final MapType data, final long fromVersion, final long toVersion) {
        for (final String path : this.paths) {
            final Object current = data.getGeneric(path);
            if (current == null) {
                continue;
            }

            final Object converted = this.type.convert((T)current, fromVersion, toVersion);

            if (converted != null) {
                data.setGeneric(path, converted);
            }
        }

        return null;
    }
}
