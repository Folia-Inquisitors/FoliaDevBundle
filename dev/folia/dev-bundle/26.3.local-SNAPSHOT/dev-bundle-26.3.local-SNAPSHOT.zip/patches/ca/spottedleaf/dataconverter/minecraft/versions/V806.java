package ca.spottedleaf.dataconverter.minecraft.versions;

import ca.spottedleaf.converter.DataConverter;
import ca.spottedleaf.dataconverter.minecraft.MCVersions;
import ca.spottedleaf.dataconverter.minecraft.datatypes.MCTypeRegistry;
import ca.spottedleaf.converter.types.ObjectType;
import ca.spottedleaf.converter.types.MapType;

public final class V806 {

    private static final int VERSION = MCVersions.V16W36A + 1;

    public static void register() {
        final DataConverter<MapType, MapType> potionWaterUpdater = new DataConverter<>(VERSION) {
            @Override
            public MapType convert(final MapType data, final long sourceVersion, final long toVersion) {
                final MapType tag = data.getOrCreateMap("tag");

                if (!tag.hasKey("Potion", ObjectType.STRING)) {
                    tag.setString("Potion", "minecraft:water");
                }

                return null;
            }
        };

        MCTypeRegistry.ITEM_STACK.addConverterForId("minecraft:potion", potionWaterUpdater);
        MCTypeRegistry.ITEM_STACK.addConverterForId("minecraft:splash_potion", potionWaterUpdater);
        MCTypeRegistry.ITEM_STACK.addConverterForId("minecraft:lingering_potion", potionWaterUpdater);
        MCTypeRegistry.ITEM_STACK.addConverterForId("minecraft:tipped_arrow", potionWaterUpdater);
    }

    private V806() {}
}
