package ca.spottedleaf.dataconverter.types.nbt;

import ca.spottedleaf.converter.types.ListType;
import ca.spottedleaf.converter.types.MapType;
import ca.spottedleaf.converter.types.ObjectType;
import ca.spottedleaf.dataconverter.types.Types;
import net.minecraft.nbt.ByteArrayTag;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.IntArrayTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.LongArrayTag;
import net.minecraft.nbt.NumericTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;

public final class NBTMapType extends MapType {

    final CompoundTag map;

    public NBTMapType() {
        this.map = new CompoundTag();
    }

    public NBTMapType(final CompoundTag tag) {
        this.map = tag;
    }

    @Override
    public NBTTypeUtil getTypeUtil() {
        return Types.NBT;
    }

    @Override
    public int hashCode() {
        return this.map.hashCode();
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || obj.getClass() != NBTMapType.class) {
            return false;
        }

        return this.map.equals(((NBTMapType)obj).map);
    }

    @Override
    public String toString() {
        return "NBTMapType{" +
                "map=" + this.map +
                '}';
    }

    @Override
    public NBTListType createEmptyList() {
        return new NBTListType();
    }

    @Override
    public NBTMapType createEmptyMap() {
        return new NBTMapType();
    }

    @Override
    public int size() {
        return this.map.size();
    }

    @Override
    public boolean isEmpty() {
        return this.map.isEmpty();
    }

    @Override
    public void clear() {
        this.map.keySet().clear();
    }

    @Override
    public Set<String> keys() {
        return this.map.keySet();
    }

    public CompoundTag getTag() {
        return this.map;
    }

    @Override
    public NBTMapType copy() {
        return new NBTMapType(this.map.copy());
    }

    @Override
    public boolean rename(final String fromKey, final String toKey) {
        final Tag value = this.map.remove(fromKey);
        if (value == null) {
            return false;
        }

        this.map.put(toKey, value);
        return true;
    }

    @Override
    public boolean renameKeys(final Function<String, String> renamer) {
        record RenameEntry(String newKey, Tag value) {}

        List<RenameEntry> renames = null;

        for (final Iterator<Map.Entry<String, Tag>> iterator = this.map.entrySet().iterator(); iterator.hasNext();) {
            final Map.Entry<String, Tag> entry = iterator.next();

            final String renamed = renamer.apply(entry.getKey());

            if (renamed == null) {
                continue;
            }

            final Tag value = entry.getValue();

            iterator.remove();

            if (renames == null) {
                renames = new ArrayList<>();
            }

            renames.add(new RenameEntry(renamed, value));
        }

        if (renames == null) {
            return false;
        }

        for (int i = 0, len = renames.size(); i < len; ++i) {
            final RenameEntry entry = renames.get(i);

            this.map.put(entry.newKey, entry.value);
        }

        return true;
    }

    @Override
    public boolean hasKey(final String key) {
        return this.map.get(key) != null;
    }

    @Override
    public boolean hasKey(final String key, final ObjectType type) {
        final Tag tag = this.map.get(key);
        if (tag == null) {
            return false;
        }

        final ObjectType valueType = NBTTypeUtil.getType(tag.getId());

        return valueType == type || ((type == ObjectType.NUMBER || type == ObjectType.BOOLEAN) && valueType.isNumber());
    }

    @Override
    public void remove(final String key) {
        this.map.remove(key);
    }

    @Override
    public Object getGenericAndRemove(final String key) {
        return Types.NBT.baseToGeneric(this.map.remove(key));
    }

    @Override
    public Object getGeneric(final String key) {
        return this.getGeneric(key, null);
    }

    @Override
    public Object getGeneric(final String key, final Object dfl) {
        final Tag tag = this.map.get(key);

        return tag == null ? dfl : Types.NBT.baseToGeneric(tag);
    }

    @Override
    public Number getNumber(final String key) {
        return this.getNumber(key, null);
    }

    @Override
    public Number getNumber(final String key, final Number dfl) {
        final Tag tag = this.map.get(key);
        if (tag instanceof NumericTag numTag) {
            return numTag.box();
        }
        return dfl;
    }

    @Override
    public BigInteger getBigInteger(final String key) {
        throw new UnsupportedOperationException();
    }

    @Override
    public BigInteger getBigInteger(final String key, final BigInteger dfl) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void setBigInteger(final String key, final BigInteger val) {
        throw new UnsupportedOperationException();
    }

    @Override
    public BigDecimal getBigDecimal(final String key) {
        throw new UnsupportedOperationException();
    }

    @Override
    public BigDecimal getBigDecimal(final String key, final BigDecimal dfl) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void setBigDecimal(final String key, final BigDecimal val) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean getBoolean(final String key) {
        return this.getByte(key) != 0;
    }

    @Override
    public boolean getBoolean(final String key, final boolean dfl) {
        return this.getByte(key, dfl ? (byte)1 : (byte)0) != 0;
    }

    @Override
    public void setBoolean(final String key, final boolean val) {
        this.setByte(key, val ? (byte)1 : (byte)0);
    }

    @Override
    public byte getByte(final String key) {
        final Tag tag = this.map.get(key);
        if (tag instanceof NumericTag numericTag) {
            return numericTag.byteValue();
        }
        return 0;
    }

    @Override
    public byte getByte(final String key, final byte dfl) {
        final Tag tag = this.map.get(key);
        if (tag instanceof NumericTag numericTag) {
            return numericTag.byteValue();
        }
        return dfl;
    }

    @Override
    public void setByte(final String key, final byte val) {
        this.map.putByte(key, val);
    }

    @Override
    public short getShort(final String key) {
        final Tag tag = this.map.get(key);
        if (tag instanceof NumericTag numericTag) {
            return numericTag.shortValue();
        }
        return 0;
    }

    @Override
    public short getShort(final String key, final short dfl) {
        final Tag tag = this.map.get(key);
        if (tag instanceof NumericTag numericTag) {
            return numericTag.shortValue();
        }
        return dfl;
    }

    @Override
    public void setShort(final String key, final short val) {
        this.map.putShort(key, val);
    }

    @Override
    public int getInt(final String key) {
        final Tag tag = this.map.get(key);
        if (tag instanceof NumericTag numericTag) {
            return numericTag.intValue();
        }
        return 0;
    }

    @Override
    public int getInt(final String key, final int dfl) {
        final Tag tag = this.map.get(key);
        if (tag instanceof NumericTag numericTag) {
            return numericTag.intValue();
        }
        return dfl;
    }

    @Override
    public void setInt(final String key, final int val) {
        this.map.putInt(key, val);
    }

    @Override
    public long getLong(final String key) {
        final Tag tag = this.map.get(key);
        if (tag instanceof NumericTag numericTag) {
            return numericTag.longValue();
        }
        return 0;
    }

    @Override
    public long getLong(final String key, final long dfl) {
        final Tag tag = this.map.get(key);
        if (tag instanceof NumericTag numericTag) {
            return numericTag.longValue();
        }
        return dfl;
    }

    @Override
    public void setLong(final String key, final long val) {
        this.map.putLong(key, val);
    }

    @Override
    public float getFloat(final String key) {
        final Tag tag = this.map.get(key);
        if (tag instanceof NumericTag numericTag) {
            return numericTag.floatValue();
        }
        return 0;
    }

    @Override
    public float getFloat(final String key, final float dfl) {
        final Tag tag = this.map.get(key);
        if (tag instanceof NumericTag numericTag) {
            return numericTag.floatValue();
        }
        return dfl;
    }

    @Override
    public void setFloat(final String key, final float val) {
        this.map.putFloat(key, val);
    }

    @Override
    public double getDouble(final String key) {
        final Tag tag = this.map.get(key);
        if (tag instanceof NumericTag numericTag) {
            return numericTag.doubleValue();
        }
        return 0;
    }

    @Override
    public double getDouble(final String key, final double dfl) {
        final Tag tag = this.map.get(key);
        if (tag instanceof NumericTag numericTag) {
            return numericTag.doubleValue();
        }
        return dfl;
    }

    @Override
    public void setDouble(final String key, final double val) {
        this.map.putDouble(key, val);
    }

    @Override
    public byte[] getBytes(final String key) {
        return this.getBytes(key, null);
    }

    @Override
    public byte[] getBytes(final String key, final byte[] dfl) {
        final Tag tag = this.map.get(key);
        if (tag instanceof ByteArrayTag byteArrayTag) {
            return byteArrayTag.getAsByteArray();
        }
        return dfl;
    }

    @Override
    public void setBytes(final String key, final byte[] val) {
        this.map.putByteArray(key, val);
    }

    @Override
    public short[] getShorts(final String key) {
        return this.getShorts(key, null);
    }

    @Override
    public short[] getShorts(final String key, final short[] dfl) {
        // NBT does not support short array
        return dfl;
    }

    @Override
    public void setShorts(final String key, final short[] val) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int[] getInts(final String key) {
        return this.getInts(key, null);
    }

    @Override
    public int[] getInts(final String key, final int[] dfl) {
        final Tag tag = this.map.get(key);
        if (tag instanceof IntArrayTag intArrayTag) {
            return intArrayTag.getAsIntArray();
        }
        return dfl;
    }

    @Override
    public void setInts(final String key, final int[] val) {
        this.map.putIntArray(key, val);
    }

    @Override
    public long[] getLongs(final String key) {
        return this.getLongs(key, null);
    }

    @Override
    public long[] getLongs(final String key, final long[] dfl) {
        final Tag tag = this.map.get(key);
        if (tag instanceof LongArrayTag longArrayTag) {
            return longArrayTag.getAsLongArray();
        }
        return dfl;
    }

    @Override
    public void setLongs(final String key, final long[] val) {
        this.map.putLongArray(key, val);
    }

    @Override
    public NBTListType getListUnchecked(final String key) {
        return this.getListUnchecked(key, null);
    }

    @Override
    public NBTListType getListUnchecked(final String key, final ListType dfl) {
        final Tag tag = this.map.get(key);
        if (tag instanceof ListTag listTag) {
            return new NBTListType(listTag);
        }
        return (NBTListType)dfl;
    }

    @Override
    public NBTListType getList(final String key, final ObjectType type) {
        return this.getList(key, type, null);
    }

    @Override
    public NBTListType getOrCreateList(final String key, final ObjectType type) {
        NBTListType ret = this.getList(key, type);
        if (ret == null) {
            this.setList(key, ret = this.createEmptyList());
        }

        return ret;
    }

    @Override
    public NBTListType getList(final String key, final ObjectType type, final ListType dfl) {
        final NBTListType ret = this.getListUnchecked(key, null);
        final ObjectType retType;
        if (ret != null && ((retType = ret.getUniformType()) == type || retType == ObjectType.UNDEFINED || retType == ObjectType.NONE)) {
            return ret;
        } else {
            return (NBTListType)dfl;
        }
    }

    @Override
    public void setList(final String key, final ListType val) {
        this.map.put(key, ((NBTListType)val).getTag());
    }

    @Override
    public NBTMapType getMap(final String key) {
        return this.getMap(key, null);
    }

    @Override
    public NBTMapType getOrCreateMap(final String key) {
        final Tag tag = this.map.get(key);
        if (tag instanceof CompoundTag compoundTag) {
            return new NBTMapType(compoundTag);
        }

        final CompoundTag ret = new CompoundTag();

        this.map.put(key, ret);

        return new NBTMapType(ret);
    }

    @Override
    public NBTMapType getMap(final String key, final MapType dfl) {
        final Tag tag = this.map.get(key);
        if (tag instanceof CompoundTag compoundTag) {
            return new NBTMapType(compoundTag);
        }
        return (NBTMapType)dfl;
    }

    @Override
    public void setMap(final String key, final MapType val) {
        this.map.put(key, ((NBTMapType)val).getTag());
    }

    @Override
    public String getString(final String key) {
        return this.getString(key, null);
    }

    @Override
    public String getString(final String key, final String dfl) {
        final Tag tag = this.map.get(key);
        if (tag instanceof StringTag strTag) {
            return strTag.value();
        }
        return dfl;
    }

    @Override
    public void setString(final String key, final String val) {
        this.map.putString(key, val);
    }

    @Override
    public void setGeneric(final String key, final Object value) {
        this.map.put(key, Types.NBT.genericToBase(Objects.requireNonNull(value)));
    }
}
