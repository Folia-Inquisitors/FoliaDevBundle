package ca.spottedleaf.dataconverter.minecraft.versions;

import ca.spottedleaf.converter.DataConverter;
import ca.spottedleaf.dataconverter.minecraft.MCVersions;
import ca.spottedleaf.dataconverter.minecraft.converters.helpers.HelperBlockFlatteningV1450;
import ca.spottedleaf.dataconverter.minecraft.datatypes.MCTypeRegistry;
import ca.spottedleaf.converter.types.MapType;

public final class V1450 {

    private static final int VERSION = MCVersions.V17W46A + 1;

    public static void register() {
        MCTypeRegistry.BLOCK_STATE.addStructureConverter(new DataConverter<>(VERSION) {
            @Override
            public Object convert(final Object input, final long sourceVersion, final long toVersion) {
                if (!(input instanceof MapType data)) {
                    return null;
                }

                final MapType ret = HelperBlockFlatteningV1450.flattenNBT(data);
                return ret == data ? null : ret.copy(); // copy to avoid problems with later state datafixers
            }
        });
    }

    private V1450() {}
}
