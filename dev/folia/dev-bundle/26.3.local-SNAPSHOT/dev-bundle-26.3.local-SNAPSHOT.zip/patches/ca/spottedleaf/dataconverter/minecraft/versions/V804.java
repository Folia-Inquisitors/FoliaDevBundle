package ca.spottedleaf.dataconverter.minecraft.versions;

import ca.spottedleaf.converter.DataConverter;
import ca.spottedleaf.dataconverter.minecraft.MCVersions;
import ca.spottedleaf.dataconverter.minecraft.datatypes.MCTypeRegistry;
import ca.spottedleaf.converter.types.ObjectType;
import ca.spottedleaf.converter.types.ListType;
import ca.spottedleaf.converter.types.MapType;

public final class V804 {

    private static final int VERSION = MCVersions.V16W35A + 1;

    public static void register() {
        MCTypeRegistry.ITEM_STACK.addConverterForId("minecraft:banner", new DataConverter<>(VERSION) {
            @Override
            public MapType convert(final MapType data, final long sourceVersion, final long toVersion) {
                final MapType tag = data.getMap("tag");
                if (tag == null) {
                    return null;
                }

                final MapType blockEntity = tag.getMap("BlockEntityTag");
                if (blockEntity == null) {
                    return null;
                }

                if (!blockEntity.hasKey("Base", ObjectType.NUMBER)) {
                    return null;
                }

                data.setShort("Damage", (short)(blockEntity.getShort("Base") & 15));

                final MapType display = tag.getMap("display");
                if (display != null) {
                    final ListType lore = display.getList("Lore", ObjectType.STRING);
                    if (lore != null) {
                        if (lore.size() == 1 && "(+NBT)".equals(lore.getString(0))) {
                            return null;
                        }
                    }
                }

                blockEntity.remove("Base");
                if (blockEntity.isEmpty()) {
                    tag.remove("BlockEntityTag");
                }

                if (tag.isEmpty()) {
                    data.remove("tag");
                }

                return null;
            }
        });
    }

    private V804() {}
}
