package ca.spottedleaf.dataconverter.minecraft.versions;

import ca.spottedleaf.converter.datatypes.DataWalker;
import ca.spottedleaf.dataconverter.minecraft.MCVersions;
import ca.spottedleaf.dataconverter.minecraft.datatypes.MCTypeRegistry;
import ca.spottedleaf.dataconverter.minecraft.walkers.generic.WalkerUtils;
import ca.spottedleaf.converter.types.MapType;

public final class V1022 {

    private static final int VERSION = MCVersions.V17W06A;

    public static void register() {
        MCTypeRegistry.PLAYER.addStructureWalker(VERSION, new DataWalker<>() {
            @Override
            public MapType walk(final MapType data, final long fromVersion, final long toVersion) {
                WalkerUtils.convert(MCTypeRegistry.ENTITY, data.getMap("RootVehicle"), "Entity", fromVersion, toVersion);

                WalkerUtils.convertList(MCTypeRegistry.ENTITY, data, "ender_pearls", fromVersion, toVersion);

                WalkerUtils.convertList(MCTypeRegistry.ITEM_STACK, data, "Inventory", fromVersion, toVersion);
                WalkerUtils.convertList(MCTypeRegistry.ITEM_STACK, data, "EnderItems", fromVersion, toVersion);

                WalkerUtils.convert(MCTypeRegistry.ENTITY, data, "ShoulderEntityLeft", fromVersion, toVersion);
                WalkerUtils.convert(MCTypeRegistry.ENTITY, data, "ShoulderEntityRight", fromVersion, toVersion);

                final MapType recipeBook = data.getMap("recipeBook");
                if (recipeBook != null) {
                    WalkerUtils.convertList(MCTypeRegistry.RECIPE, recipeBook, "recipes", fromVersion, toVersion);
                    WalkerUtils.convertList(MCTypeRegistry.RECIPE, recipeBook, "toBeDisplayed", fromVersion, toVersion);
                }

                return null;
            }
        });

        MCTypeRegistry.HOTBAR.addStructureWalker(VERSION, new DataWalker<>() {
            @Override
            public MapType walk(final MapType data, final long fromVersion, final long toVersion) {
                for (final String key : data.keys()) {
                    WalkerUtils.convertList(MCTypeRegistry.ITEM_STACK, data, key, fromVersion, toVersion);
                }

                return null;
            }
        });
    }

    private V1022() {}
}
