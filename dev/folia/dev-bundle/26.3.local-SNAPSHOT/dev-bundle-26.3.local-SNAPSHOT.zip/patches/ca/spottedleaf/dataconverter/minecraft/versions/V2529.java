package ca.spottedleaf.dataconverter.minecraft.versions;

import ca.spottedleaf.converter.DataConverter;
import ca.spottedleaf.dataconverter.minecraft.MCVersions;
import ca.spottedleaf.dataconverter.minecraft.datatypes.MCTypeRegistry;
import ca.spottedleaf.converter.types.MapType;

public final class V2529 {

    private static final int VERSION = MCVersions.V20W17A;

    public static void register() {
        MCTypeRegistry.ENTITY.addConverterForId("minecraft:strider", new DataConverter<>(VERSION) {
            @Override
            public MapType convert(final MapType data, final long sourceVersion, final long toVersion) {
                if (data.getBoolean("NoGravity")) {
                    data.setBoolean("NoGravity", false);
                }
                return null;
            }
        });
    }

    private V2529() {}
}
