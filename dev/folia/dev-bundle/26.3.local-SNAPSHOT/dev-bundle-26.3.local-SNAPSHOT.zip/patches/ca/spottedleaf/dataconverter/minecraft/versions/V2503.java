package ca.spottedleaf.dataconverter.minecraft.versions;

import ca.spottedleaf.converter.DataConverter;
import ca.spottedleaf.dataconverter.minecraft.MCVersions;
import ca.spottedleaf.dataconverter.minecraft.converters.advancements.ConverterAbstractAdvancementsRename;
import ca.spottedleaf.dataconverter.minecraft.datatypes.MCTypeRegistry;
import ca.spottedleaf.converter.types.MapType;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public final class V2503 {

    private static final int VERSION = MCVersions.V1_15_2 + 273;

    private static final Set<String> WALL_BLOCKS = new HashSet<>(
            ImmutableSet.of(
                    "minecraft:andesite_wall",
                    "minecraft:brick_wall",
                    "minecraft:cobblestone_wall",
                    "minecraft:diorite_wall",
                    "minecraft:end_stone_brick_wall",
                    "minecraft:granite_wall",
                    "minecraft:mossy_cobblestone_wall",
                    "minecraft:mossy_stone_brick_wall",
                    "minecraft:nether_brick_wall",
                    "minecraft:prismarine_wall",
                    "minecraft:red_nether_brick_wall",
                    "minecraft:red_sandstone_wall",
                    "minecraft:sandstone_wall",
                    "minecraft:stone_brick_wall"
            )
    );

    private static void changeWallProperty(final MapType properties, final String path) {
        final String property = properties.getString(path);
        if (property != null) {
            properties.setString(path, "true".equals(property) ? "low" : "none");
        }
    }

    public static void register() {
        MCTypeRegistry.BLOCK_STATE.addStructureConverter(new DataConverter<>(VERSION) {
            @Override
            public Object convert(final Object input, final long sourceVersion, final long toVersion) {
                if (!(input instanceof MapType data)) {
                    return null;
                }

                if (!WALL_BLOCKS.contains(data.getString("Name"))) {
                    return null;
                }

                final MapType properties = data.getMap("Properties");
                if (properties == null) {
                    return null;
                }

                changeWallProperty(properties, "east");
                changeWallProperty(properties, "west");
                changeWallProperty(properties, "north");
                changeWallProperty(properties, "south");

                return null;
            }
        });
        ConverterAbstractAdvancementsRename.register(VERSION, new HashMap<>(
                ImmutableMap.of(
                        "minecraft:recipes/misc/composter", "minecraft:recipes/decorations/composter"
                )
        )::get);
    }

    private V2503() {}
}
