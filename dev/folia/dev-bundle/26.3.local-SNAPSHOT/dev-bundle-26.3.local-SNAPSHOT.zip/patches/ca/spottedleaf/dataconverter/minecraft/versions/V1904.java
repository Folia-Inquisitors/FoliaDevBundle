package ca.spottedleaf.dataconverter.minecraft.versions;

import ca.spottedleaf.converter.DataConverter;
import ca.spottedleaf.dataconverter.minecraft.MCVersions;
import ca.spottedleaf.dataconverter.minecraft.datatypes.MCTypeRegistry;
import ca.spottedleaf.converter.types.MapType;

public final class V1904 {

    private static final int VERSION = MCVersions.V18W43C + 1;

    public static void register() {
        MCTypeRegistry.ENTITY.addConverterForId("minecraft:ocelot", new DataConverter<>(VERSION) {
            @Override
            public MapType convert(final MapType data, final long sourceVersion, final long toVersion) {
                final int catType = data.getInt("CatType");

                if (catType == 0) {
                    final String owner = data.getString("Owner");
                    final String ownerUUID = data.getString("OwnerUUID");
                    if ((owner != null && owner.length() > 0) || (ownerUUID != null && ownerUUID.length() > 0)) {
                        data.setBoolean("Trusting", true);
                    }
                } else if (catType > 0 && catType < 4) {
                    data.setString("id", "minecraft:cat");
                    data.setString("OwnerUUID", data.getString("OwnerUUID", ""));
                }

                return null;
            }
        });

        //registerMob("minecraft:cat"); // changed to simple in 1.21.5
    }

    private V1904() {}
}
