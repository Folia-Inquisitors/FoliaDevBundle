@NullMarked
package org.bukkit.craftbukkit.inventory.view.builder;

import org.jspecify.annotations.NullMarked;
