package org.bukkit.craftbukkit.util;

public interface Handleable<M> {

    M getHandle();
}
