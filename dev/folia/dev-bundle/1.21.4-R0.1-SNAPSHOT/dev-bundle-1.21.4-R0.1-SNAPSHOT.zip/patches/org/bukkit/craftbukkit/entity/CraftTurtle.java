package org.bukkit.craftbukkit.entity;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.entity.Turtle;

public class CraftTurtle extends CraftAnimals implements Turtle {

    public CraftTurtle(CraftServer server, net.minecraft.world.entity.animal.Turtle entity) {
        super(server, entity);
    }

    // Folia start - region threading
    @Override
    public net.minecraft.world.entity.animal.Turtle getHandleRaw() {
        return (net.minecraft.world.entity.animal.Turtle)this.entity;
    }
    // Folia end - region threading

    @Override
    public net.minecraft.world.entity.animal.Turtle getHandle() {
        ca.spottedleaf.moonrise.common.util.TickThread.ensureTickThread(this.entity, "Accessing entity state off owning region's thread"); // Folia - region threading
        return (net.minecraft.world.entity.animal.Turtle) super.getHandle();
    }

    @Override
    public String toString() {
        return "CraftTurtle";
    }

    @Override
    public boolean hasEgg() {
        return this.getHandle().hasEgg();
    }

    @Override
    public boolean isLayingEgg() {
        return this.getHandle().isLayingEgg();
    }

    @Override
    public org.bukkit.Location getHome() {
        return io.papermc.paper.util.MCUtil.toLocation(this.getHandle().level(), this.getHandle().getHomePos());
    }

    @Override
    public void setHome(org.bukkit.Location location) {
        this.getHandle().setHomePos(io.papermc.paper.util.MCUtil.toBlockPosition(location));
    }

    @Override
    public boolean isGoingHome() {
        return this.getHandle().isGoingHome();
    }

    @Override
    public void setHasEgg(boolean hasEgg) {
        this.getHandle().setHasEgg(hasEgg);
    }
}
