package org.bukkit.craftbukkit.legacy.enums;

/**
 *  A crash dummy to use, instead of the old enums which matured to Abstracthood or Interfacehood and the baby enums which are still growing.
 */
public enum DummyEnum {
}
