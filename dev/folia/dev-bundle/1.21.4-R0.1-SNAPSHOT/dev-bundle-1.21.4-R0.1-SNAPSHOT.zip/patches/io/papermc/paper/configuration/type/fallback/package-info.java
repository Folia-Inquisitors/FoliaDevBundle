@NullMarked
package io.papermc.paper.configuration.type.fallback;

import org.jspecify.annotations.NullMarked;
