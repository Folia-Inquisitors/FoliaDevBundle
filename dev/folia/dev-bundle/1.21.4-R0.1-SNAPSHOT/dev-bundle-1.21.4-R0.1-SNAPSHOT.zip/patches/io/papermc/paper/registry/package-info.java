@NullMarked
package io.papermc.paper.registry;

import org.jspecify.annotations.NullMarked;
