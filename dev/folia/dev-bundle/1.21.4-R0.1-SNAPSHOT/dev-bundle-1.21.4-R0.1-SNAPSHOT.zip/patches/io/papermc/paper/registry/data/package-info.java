@NullMarked
package io.papermc.paper.registry.data;

import org.jspecify.annotations.NullMarked;
