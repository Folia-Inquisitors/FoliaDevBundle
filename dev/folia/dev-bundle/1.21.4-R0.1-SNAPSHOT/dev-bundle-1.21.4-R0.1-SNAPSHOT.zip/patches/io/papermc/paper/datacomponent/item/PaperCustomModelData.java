package io.papermc.paper.datacomponent.item;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import io.papermc.paper.util.MCUtil;
import org.bukkit.Color;
import org.bukkit.craftbukkit.util.Handleable;

public record PaperCustomModelData(
    net.minecraft.world.item.component.CustomModelData impl
) implements CustomModelData, Handleable<net.minecraft.world.item.component.CustomModelData> {

    @Override
    public net.minecraft.world.item.component.CustomModelData getHandle() {
        return this.impl;
    }

    @Override
    public List<Float> floats() {
        return Collections.unmodifiableList(this.impl.floats());
    }

    @Override
    public List<Boolean> flags() {
        return Collections.unmodifiableList(this.impl.flags());
    }

    @Override
    public List<String> strings() {
        return Collections.unmodifiableList(this.impl.strings());
    }

    @Override
    public List<Color> colors() {
        return MCUtil.transformUnmodifiable(this.impl.colors(), Color::fromRGB);
    }

    static final class BuilderImpl implements CustomModelData.Builder {

        private final List<Float> floats = new ArrayList<>();
        private final List<Boolean> flags = new ArrayList<>();
        private final List<String> strings = new ArrayList<>();
        private final List<Integer> colors = new ArrayList<>();

        @Override
        public Builder addFloat(final float num) {
            this.floats.add(num);
            return this;
        }

        @Override
        public Builder addFloats(final List<Float> nums) {
            this.floats.addAll(nums);
            return this;
        }

        @Override
        public Builder addFlag(final boolean flag) {
            this.flags.add(flag);
            return this;
        }

        @Override
        public Builder addFlags(final List<Boolean> flags) {
            this.flags.addAll(flags);
            return this;
        }

        @Override
        public Builder addString(final String string) {
            this.strings.add(string);
            return this;
        }

        @Override
        public Builder addStrings(final List<String> strings) {
            this.strings.addAll(strings);
            return this;
        }

        @Override
        public Builder addColor(final Color color) {
            this.colors.add(color.asRGB());
            return this;
        }

        @Override
        public Builder addColors(final List<Color> colors) {
            for (Color color : colors) {
                this.addColor(color);
            }
            return this;
        }

        @Override
        public CustomModelData build() {
            return new PaperCustomModelData(
                new net.minecraft.world.item.component.CustomModelData(
                    this.floats,
                    this.flags,
                    this.strings,
                    this.colors
                )
            );
        }

    }
}
