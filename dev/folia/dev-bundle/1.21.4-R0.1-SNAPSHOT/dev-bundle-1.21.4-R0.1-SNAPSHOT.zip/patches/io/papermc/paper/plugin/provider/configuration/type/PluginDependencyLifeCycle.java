package io.papermc.paper.plugin.provider.configuration.type;

public enum PluginDependencyLifeCycle {
    BOOTSTRAP,
    SERVER
}
