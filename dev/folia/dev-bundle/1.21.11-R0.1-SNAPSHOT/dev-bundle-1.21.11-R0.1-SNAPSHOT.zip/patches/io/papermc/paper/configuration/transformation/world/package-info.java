@NullMarked
package io.papermc.paper.configuration.transformation.world;

import org.jspecify.annotations.NullMarked;
