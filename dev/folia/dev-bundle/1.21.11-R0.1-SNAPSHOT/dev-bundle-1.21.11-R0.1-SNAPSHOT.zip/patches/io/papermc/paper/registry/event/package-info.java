@NullMarked
package io.papermc.paper.registry.event;

import org.jspecify.annotations.NullMarked;
