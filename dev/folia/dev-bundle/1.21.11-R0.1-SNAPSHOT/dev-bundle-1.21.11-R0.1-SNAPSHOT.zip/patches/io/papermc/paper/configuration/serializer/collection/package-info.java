@NullMarked
package io.papermc.paper.configuration.serializer.collection;

import org.jspecify.annotations.NullMarked;
