/**
 * Relating to block attacks for components.
 */
@NullMarked
package io.papermc.paper.datacomponent.item.blocksattacks;

import org.jspecify.annotations.NullMarked;
