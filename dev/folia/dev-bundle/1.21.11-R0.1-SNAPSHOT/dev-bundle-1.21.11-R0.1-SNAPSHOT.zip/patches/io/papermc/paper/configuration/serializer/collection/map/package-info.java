@NullMarked
package io.papermc.paper.configuration.serializer.collection.map;

import org.jspecify.annotations.NullMarked;
