@NullMarked
package io.papermc.paper.registry.legacy;

import org.jspecify.annotations.NullMarked;
