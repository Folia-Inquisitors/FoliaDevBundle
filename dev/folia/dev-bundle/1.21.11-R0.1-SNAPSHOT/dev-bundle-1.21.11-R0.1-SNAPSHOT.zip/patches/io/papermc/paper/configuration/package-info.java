@NullMarked
package io.papermc.paper.configuration;

import org.jspecify.annotations.NullMarked;
