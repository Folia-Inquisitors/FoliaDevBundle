@NullMarked
package io.papermc.paper.registry.entry;

import org.jspecify.annotations.NullMarked;
