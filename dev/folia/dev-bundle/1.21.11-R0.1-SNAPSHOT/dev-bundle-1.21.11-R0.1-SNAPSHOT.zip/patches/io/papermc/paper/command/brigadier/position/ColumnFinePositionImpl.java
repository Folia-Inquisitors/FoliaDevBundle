package io.papermc.paper.command.brigadier.position;

import io.papermc.paper.command.brigadier.argument.position.ColumnFinePosition;

public record ColumnFinePositionImpl(double x, double z) implements ColumnFinePosition {
}
