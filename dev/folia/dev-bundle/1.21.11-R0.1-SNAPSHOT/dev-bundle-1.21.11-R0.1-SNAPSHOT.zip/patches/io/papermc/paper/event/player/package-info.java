@NullMarked
package io.papermc.paper.event.player;

import org.jspecify.annotations.NullMarked;
