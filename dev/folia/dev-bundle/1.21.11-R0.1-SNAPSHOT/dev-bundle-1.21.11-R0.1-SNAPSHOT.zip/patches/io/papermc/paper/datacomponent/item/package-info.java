@NullMarked
package io.papermc.paper.datacomponent.item;

import org.jspecify.annotations.NullMarked;
