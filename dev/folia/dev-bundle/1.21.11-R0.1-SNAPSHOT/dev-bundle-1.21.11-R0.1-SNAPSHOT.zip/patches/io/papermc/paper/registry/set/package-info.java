@NullMarked
package io.papermc.paper.registry.set;

import org.jspecify.annotations.NullMarked;
