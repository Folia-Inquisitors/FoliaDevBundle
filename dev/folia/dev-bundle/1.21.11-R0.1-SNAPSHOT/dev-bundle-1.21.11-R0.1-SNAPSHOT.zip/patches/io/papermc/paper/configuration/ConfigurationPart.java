package io.papermc.paper.configuration;

/**
 * Marker interface for unique sections of a configuration.
 */
public abstract class ConfigurationPart {
}
