@NullMarked
package io.papermc.paper.configuration.transformation.global;

import org.jspecify.annotations.NullMarked;
