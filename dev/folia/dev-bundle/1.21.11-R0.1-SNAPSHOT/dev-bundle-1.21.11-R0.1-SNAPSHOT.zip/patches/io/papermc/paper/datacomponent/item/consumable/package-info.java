/**
 * Relating to consumable effects for components.
 */
@NullMarked
package io.papermc.paper.datacomponent.item.consumable;

import org.jspecify.annotations.NullMarked;
