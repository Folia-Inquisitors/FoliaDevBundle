@NullMarked
package io.papermc.paper.datacomponent;

import org.jspecify.annotations.NullMarked;
