@NullMarked
package io.papermc.paper.configuration.transformation;

import org.jspecify.annotations.NullMarked;
