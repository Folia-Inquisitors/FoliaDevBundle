@NullMarked
package io.papermc.paper.configuration.transformation.world.versioned;

import org.jspecify.annotations.NullMarked;
