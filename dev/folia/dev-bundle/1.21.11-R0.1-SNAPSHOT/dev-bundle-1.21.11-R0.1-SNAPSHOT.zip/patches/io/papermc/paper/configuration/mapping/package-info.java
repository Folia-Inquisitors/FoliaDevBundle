@NullMarked
package io.papermc.paper.configuration.mapping;

import org.jspecify.annotations.NullMarked;
