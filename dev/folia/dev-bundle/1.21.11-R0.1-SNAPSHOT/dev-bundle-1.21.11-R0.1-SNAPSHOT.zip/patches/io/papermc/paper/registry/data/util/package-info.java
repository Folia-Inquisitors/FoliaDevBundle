@NullMarked
package io.papermc.paper.registry.data.util;

import org.jspecify.annotations.NullMarked;
