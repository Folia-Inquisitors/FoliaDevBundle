@NullMarked
package io.papermc.paper.configuration.type.number;

import org.jspecify.annotations.NullMarked;
