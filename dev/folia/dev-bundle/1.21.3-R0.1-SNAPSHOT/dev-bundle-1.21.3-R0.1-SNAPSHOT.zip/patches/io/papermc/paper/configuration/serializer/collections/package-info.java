@NullMarked
package io.papermc.paper.configuration.serializer.collections;

import org.jspecify.annotations.NullMarked;
