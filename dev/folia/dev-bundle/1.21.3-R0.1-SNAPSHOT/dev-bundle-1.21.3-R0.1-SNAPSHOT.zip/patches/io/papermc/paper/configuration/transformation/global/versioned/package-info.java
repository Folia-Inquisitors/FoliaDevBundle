@NullMarked
package io.papermc.paper.configuration.transformation.global.versioned;

import org.jspecify.annotations.NullMarked;
