@NullMarked
package io.papermc.paper.configuration.serializer;

import org.jspecify.annotations.NullMarked;
