package ca.spottedleaf.moonrise.patches.collisions.shape;

public interface CollisionDiscreteVoxelShape {

    public ca.spottedleaf.moonrise.patches.collisions.shape.CachedShapeData moonrise$getOrCreateCachedShapeData();

}
