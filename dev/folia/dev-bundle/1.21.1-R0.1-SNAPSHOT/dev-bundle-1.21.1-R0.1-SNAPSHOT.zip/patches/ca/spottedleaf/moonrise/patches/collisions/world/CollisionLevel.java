package ca.spottedleaf.moonrise.patches.collisions.world;

public interface CollisionLevel {

    public int moonrise$getMinSection();

    public int moonrise$getMaxSection();

}
