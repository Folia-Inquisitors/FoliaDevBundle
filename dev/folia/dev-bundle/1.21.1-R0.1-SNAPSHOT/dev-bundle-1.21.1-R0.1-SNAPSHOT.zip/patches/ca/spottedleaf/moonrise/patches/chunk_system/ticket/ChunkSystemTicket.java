package ca.spottedleaf.moonrise.patches.chunk_system.ticket;

public interface ChunkSystemTicket<T> {

    public long moonrise$getRemoveDelay();

    public void moonrise$setRemoveDelay(final long removeDelay);

}
