/**
 * Classes in this package are supposed to connect components of {@link io.papermc.paper.plugin.entrypoint} and {@link io.papermc.paper.plugin.provider} packages.
 * @see io.papermc.paper.plugin.entrypoint.Entrypoint
 */
package io.papermc.paper.plugin.storage;
