package io.papermc.paper.network;

/**
 * Internal connection pipeline events.
 */
public enum ConnectionEvent {

    COMPRESSION_THRESHOLD_SET,
    COMPRESSION_DISABLED
}
