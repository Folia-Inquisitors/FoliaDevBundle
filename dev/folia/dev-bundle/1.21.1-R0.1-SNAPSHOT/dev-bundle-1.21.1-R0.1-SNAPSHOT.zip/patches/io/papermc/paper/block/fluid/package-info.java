@DefaultQualifier(NonNull.class)
package io.papermc.paper.block.fluid;

import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.framework.qual.DefaultQualifier;
