@DefaultQualifier(NonNull.class)
package io.papermc.paper.registry.event;

import org.checkerframework.checker.nullness.qual.NonNull;
import org.checkerframework.framework.qual.DefaultQualifier;
