package ca.spottedleaf.dataconverter.minecraft.versions;

import ca.spottedleaf.dataconverter.minecraft.MCVersions;

public final class V501 {

    private static final int VERSION = MCVersions.V16W20A;

    public static void register() {
        //registerMob("PolarBear"); // is now simple in 1.21.5
    }

    private V501() {}
}
