package ca.spottedleaf.dataconverter.minecraft.versions;

import ca.spottedleaf.dataconverter.minecraft.MCVersions;

public final class V2502 {

    private static final int VERSION = MCVersions.V1_15_2 + 272;

    public static void register() {
        //registerMob("minecraft:hoglin"); changed to simple in 1.21.5
    }

    private V2502() {}
}
