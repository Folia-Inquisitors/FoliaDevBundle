package ca.spottedleaf.dataconverter.minecraft.versions;

import ca.spottedleaf.dataconverter.minecraft.MCVersions;

public final class V1931 {

    private static final int VERSION = MCVersions.V19W06A;

    public static void register() {
        //registerMob("minecraft:fox"); // changed to simple in 1.21.5
    }

    private V1931() {}

}
