package ca.spottedleaf.dataconverter.minecraft.versions;

import ca.spottedleaf.dataconverter.minecraft.MCVersions;

public final class V2671 {

    private static final int VERSION = MCVersions.V1_16_5 + 85;

    public static void register() {
        //registerMob("minecraft:goat"); // changed to simple in 1.21.5
    }

    private V2671() {}
}
