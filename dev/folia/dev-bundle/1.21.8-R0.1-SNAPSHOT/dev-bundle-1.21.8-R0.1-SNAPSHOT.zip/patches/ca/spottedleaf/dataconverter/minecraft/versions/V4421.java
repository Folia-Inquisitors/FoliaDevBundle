package ca.spottedleaf.dataconverter.minecraft.versions;

import ca.spottedleaf.dataconverter.minecraft.MCVersions;

public final class V4421 {

    private static final int VERSION = MCVersions.V1_21_5 + 96;

    public static void register() {
        // happy_ghast is simple entity
    }

    private V4421() {}
}
