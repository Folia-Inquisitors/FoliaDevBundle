package ca.spottedleaf.moonrise.patches.blockstate_propertyaccess;

public interface PropertyAccessStateHolder {

    public long moonrise$getTableIndex();

}
