package ca.spottedleaf.dataconverter.minecraft.versions;

import ca.spottedleaf.dataconverter.minecraft.MCVersions;

public final class V2519 {

    private static final int VERSION = MCVersions.V20W12A + 4;

    public static void register() {
        //registerMob("minecraft:strider"); // changed to simple in 1.21.5
    }

    private V2519() {}
}
