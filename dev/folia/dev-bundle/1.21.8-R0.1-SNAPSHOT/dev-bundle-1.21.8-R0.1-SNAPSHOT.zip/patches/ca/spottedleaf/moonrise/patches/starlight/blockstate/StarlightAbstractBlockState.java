package ca.spottedleaf.moonrise.patches.starlight.blockstate;

public interface StarlightAbstractBlockState {

    public boolean starlight$isConditionallyFullOpaque();

}
