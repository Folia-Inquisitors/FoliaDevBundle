package ca.spottedleaf.dataconverter.minecraft.versions;

import ca.spottedleaf.dataconverter.minecraft.MCVersions;

public final class V4302 {

    private static final int VERSION = MCVersions.V25W02A + 4;

    public static void register() {


        // test_block is simple TE
        // test_instance_block is simple TE
    }

    private V4302() {}
}
