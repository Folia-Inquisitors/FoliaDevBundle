package ca.spottedleaf.moonrise.patches.collisions.shape;

public interface CollisionDiscreteVoxelShape {

    public CachedShapeData moonrise$getOrCreateCachedShapeData();

}
