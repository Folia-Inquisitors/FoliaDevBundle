package ca.spottedleaf.dataconverter.minecraft.versions;

import ca.spottedleaf.dataconverter.converters.DataConverter;
import ca.spottedleaf.dataconverter.minecraft.MCVersions;
import ca.spottedleaf.dataconverter.minecraft.datatypes.MCTypeRegistry;
import ca.spottedleaf.dataconverter.types.MapType;

public final class V1905 {

    private static final int VERSION = MCVersions.V18W43C + 2;

    public static void register() {
        MCTypeRegistry.CHUNK.addStructureConverter(new DataConverter<>(VERSION) {
            @Override
            public MapType convert(final MapType data, final long sourceVersion, final long toVersion) {
                final MapType level = data.getMap("Level");

                if (level == null) {
                    return null;
                }

                final String status = level.getString("Status");

                if ("postprocessed".equals(status)) {
                    level.setString("Status", "fullchunk");
                }

                return null;
            }
        });
    }

    private V1905() {}
}
