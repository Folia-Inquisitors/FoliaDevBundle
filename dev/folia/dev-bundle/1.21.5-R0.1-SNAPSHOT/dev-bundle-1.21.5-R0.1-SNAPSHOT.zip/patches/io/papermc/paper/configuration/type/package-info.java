@NullMarked
package io.papermc.paper.configuration.type;

import org.jspecify.annotations.NullMarked;
