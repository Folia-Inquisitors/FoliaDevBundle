@NullMarked
package io.papermc.paper.registry.event.type;

import org.jspecify.annotations.NullMarked;
