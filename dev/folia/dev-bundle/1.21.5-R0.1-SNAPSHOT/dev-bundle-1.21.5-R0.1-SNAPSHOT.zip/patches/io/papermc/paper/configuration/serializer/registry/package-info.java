@NullMarked
package io.papermc.paper.configuration.serializer.registry;

import org.jspecify.annotations.NullMarked;
