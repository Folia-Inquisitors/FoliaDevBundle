package ca.spottedleaf.moonrise.patches.chunk_system.storage;

import net.minecraft.world.level.chunk.storage.RegionFileStorage;

public interface ChunkSystemChunkStorage {

    public RegionFileStorage moonrise$getRegionStorage();

}
