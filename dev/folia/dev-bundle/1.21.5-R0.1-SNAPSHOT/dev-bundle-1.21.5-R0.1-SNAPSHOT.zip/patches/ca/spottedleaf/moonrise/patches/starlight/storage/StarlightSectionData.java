package ca.spottedleaf.moonrise.patches.starlight.storage;

public interface StarlightSectionData {

    public int starlight$getBlockLightState();

    public void starlight$setBlockLightState(final int state);

    public int starlight$getSkyLightState();

    public void starlight$setSkyLightState(final int state);

}
