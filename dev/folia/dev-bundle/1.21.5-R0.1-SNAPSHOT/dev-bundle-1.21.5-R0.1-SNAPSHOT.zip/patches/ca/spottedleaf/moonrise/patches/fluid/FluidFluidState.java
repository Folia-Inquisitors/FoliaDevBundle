package ca.spottedleaf.moonrise.patches.fluid;

public interface FluidFluidState {
    public void moonrise$initCaches();
}
